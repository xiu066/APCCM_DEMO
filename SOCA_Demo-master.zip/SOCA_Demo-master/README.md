# SOCA_Demo
A Petri Net based process modeling, verifying and analyzing application. Developed by Javascript, JQuery and  jsPlumb
* [See the demo](http://htmlpreview.github.io/?https://github.com/xiu066/SOCA_Demo/blob/master/index.html)
